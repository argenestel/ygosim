#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/wrapper"
sources=(cpp/ygo/*.cpp)
for file in cpp/ygo/lua/src/*.c; do
  case "${file##*/}" in lua.c|onelua.c|ltests.c) continue ;; esac
  sources+=("$file")
done
"${EMXX:-em++}" -x c++ -std=c++17 -Os -g0 --closure 1 -sASSERTIONS=0 \
  -sMODULARIZE=1 -sFILESYSTEM=0 -sALLOW_MEMORY_GROWTH=1 -sMALLOC=emmalloc \
  -fwasm-exceptions -sSUPPORT_LONGJMP=wasm -fno-rtti -sNO_EXIT_RUNTIME=1 \
  -sENVIRONMENT=web \
  "-sEXPORTED_FUNCTIONS=['_malloc','_free']" \
  "-sEXPORTED_RUNTIME_METHODS=['stackSave','stackRestore','stackAlloc','getValue','stringToUTF8','lengthBytesUTF8','HEAP8','HEAPU8']" \
  -Icpp/ygo/lua/src "${sources[@]}" cpp/wasm.cpp -o ../output/ocgcore.sync.mjs
